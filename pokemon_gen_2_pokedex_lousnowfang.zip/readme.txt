This is just a simple tracker for catch 'em all runs in Gen 2. 
It displays Pokemon in rows of 12 and can be toggled on and off.
Using EmoTracker, it can be saved for multiple sessions.




Huge thanks to Mike Trethewey in the EmuTracker Discord for helping write the common.json file and helping with a lot of other projects. 
Dude, you're a literal lifesaver.

Also thanks to StormRider for providing a package to use as a base.